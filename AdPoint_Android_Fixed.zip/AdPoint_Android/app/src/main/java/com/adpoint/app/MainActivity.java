package com.adpoint.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final String AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"; // Google test rewarded ad
    private static final int DAILY_LIMIT = 20, POINTS_PER_AD = 50, REDEEM_POINTS = 2000;

    private SharedPreferences sp;
    private RewardedAd rewardedAd;
    private Button watchButton;
    private TextView pointsText, adsText, statusText;
    private LinearLayout content;
    private String lastAdError = "";
    private int points, adsToday;
    private String day;

    int dp(float x) {
        return (int) (x * getResources().getDisplayMetrics().density + .5f);
    }

    TextView tv(String text, int size, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(dp(20), dp(12), dp(20), dp(12));
        return t;
    }

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);

        sp = getSharedPreferences("adpoint", MODE_PRIVATE);
        day = sp.getString("day", "");
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());

        if (!today.equals(day)) {
            adsToday = 0;
            day = today;
            save();
        }

        points = sp.getInt("points", 0);
        adsToday = sp.getInt("ads", 0);

        MobileAds.initialize(this, status -> {});
        buildHome();
        loadRewardedAd();
    }

    void base(int headerColor, int backgroundColor) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(backgroundColor);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(20), dp(20), dp(20), dp(20));
        header.setBackgroundColor(headerColor);

        TextView brand = tv("AdPoint", 25, Color.WHITE);
        brand.setTypeface(null, 1);
        header.addView(brand);

        root.addView(header, new LinearLayout.LayoutParams(-1, dp(120)));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(2), dp(4), dp(2), dp(8));
        nav.setBackgroundColor(Color.WHITE);

        String[] labels = {"⌂\nHome", "▶\nWatch", "▣\nWallet", "🎁\nRedeem", "●\nProfile"};

        for (String label : labels) {
            Button n = new Button(this);
            n.setText(label);
            n.setTextSize(11);
            n.setAllCaps(false);
            n.setGravity(Gravity.CENTER);
            n.setPadding(0, 0, 0, 0);

            nav.addView(n, new LinearLayout.LayoutParams(0, dp(58), 1));

            if (label.contains("Home")) n.setOnClickListener(v -> buildHome());
            else if (label.contains("Watch")) n.setOnClickListener(v -> buildWatch());
            else if (label.contains("Wallet")) n.setOnClickListener(v -> buildWallet());
            else if (label.contains("Redeem")) n.setOnClickListener(v -> buildRedeem());
            else n.setOnClickListener(v -> buildProfile());
        }

        root.addView(nav, new LinearLayout.LayoutParams(-1, dp(68)));
        setContentView(root);
    }

    void buildHome() {
        base(Color.rgb(25, 84, 165), Color.rgb(246, 248, 255));
        content.removeAllViews();

        TextView title = tv("Your Points", 15, Color.GRAY);
        content.addView(title);

        pointsText = tv(points + " points", 36, Color.rgb(20, 30, 65));
        pointsText.setTypeface(null, 1);
        content.addView(pointsText);

        adsText = tv("Today's Ads: " + adsToday + " / " + DAILY_LIMIT, 16, Color.DKGRAY);
        content.addView(adsText);

        content.addView(tv("1 ad = 50 points  •  2,000 points = ₹10 redeem",
                14, Color.rgb(35, 90, 170)));

        Button goWatch = new Button(this);
        goWatch.setText("▶  Go to Watch & Earn 50 Points");
        goWatch.setAllCaps(false);
        goWatch.setTextColor(Color.WHITE);
        goWatch.setBackgroundResource(R.drawable.button_bg);
        content.addView(goWatch, new LinearLayout.LayoutParams(-1, dp(62)));
        goWatch.setOnClickListener(v -> buildWatch());

        TextView how = tv("How it works", 20, Color.rgb(30, 35, 50));
        how.setTypeface(null, 1);
        content.addView(how);

        content.addView(tv("▶  Watch Ads\n     Watch rewarded ads and earn points", 16, Color.DKGRAY));
        content.addView(tv("★  Earn Points\n     50 points are added after a genuine reward", 16, Color.DKGRAY));
        content.addView(tv("🎁  Redeem\n     Collect 2,000 points and submit a redeem request", 16, Color.DKGRAY));

        updateButtons();
    }

    void buildWatch() {
        base(Color.rgb(15, 18, 35), Color.rgb(8, 12, 27));
        content.removeAllViews();

        TextView title = tv("Watch & Earn", 26, Color.WHITE);
        title.setTypeface(null, 1);
        content.addView(title);

        pointsText = tv(points + " points", 32, Color.rgb(220, 205, 255));
        pointsText.setTypeface(null, 1);
        content.addView(pointsText);

        adsText = tv("Today's Ads: " + adsToday + " / " + DAILY_LIMIT, 16, Color.rgb(220, 220, 230));
        content.addView(adsText);

        content.addView(tv("Watch a rewarded ad and earn 50 points after the ad is completed.",
                14, Color.rgb(180, 175, 205)));

        watchButton = new Button(this);
        watchButton.setText("▶  Watch Ad & Earn 50 Points");
        watchButton.setAllCaps(false);
        watchButton.setTextColor(Color.WHITE);
        watchButton.setBackgroundResource(R.drawable.button_bg);
        content.addView(watchButton, new LinearLayout.LayoutParams(-1, dp(64)));
        watchButton.setOnClickListener(v -> watchAd());

        statusText = tv("", 14, Color.rgb(190, 185, 220));
        content.addView(statusText);

        content.addView(tv("ⓘ  Rewards are granted only after the ad SDK reports a genuine earned reward.",
                14, Color.rgb(190, 185, 220)));

        updateButtons();
    }

    void buildWallet() {
        base(Color.rgb(0, 121, 107), Color.rgb(245, 250, 249));
        content.removeAllViews();

        TextView title = tv("Wallet", 25, Color.rgb(20, 55, 55));
        title.setTypeface(null, 1);
        content.addView(title);

        content.addView(tv(points + " points available", 28, Color.rgb(20, 55, 55)));
        content.addView(tv("Total earned: " + sp.getInt("earned", 0) + " points", 16, Color.DKGRAY));
        content.addView(tv("Redeemed: " + sp.getInt("redeemed", 0) + " points", 16, Color.DKGRAY));
    }

    void buildRedeem() {
        base(Color.rgb(255, 111, 0), Color.rgb(255, 250, 245));
        content.removeAllViews();

        TextView title = tv("Redeem", 25, Color.rgb(70, 45, 20));
        title.setTypeface(null, 1);
        content.addView(title);

        content.addView(tv("🎁  Google Play Redeem Code", 20, Color.rgb(70, 45, 20)));
        content.addView(tv("2,000 points = ₹10 redeem request", 15, Color.DKGRAY));

        Button r = new Button(this);
        r.setText("Redeem Now");
        r.setAllCaps(false);
        content.addView(r, new LinearLayout.LayoutParams(-1, dp(60)));
        r.setOnClickListener(v -> requestRedeem());

        content.addView(tv("Balance: " + points + " points", 15, Color.GRAY));
    }

    void addProfileRow(String icon, String title, String subtitle, View.OnClickListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(10), dp(12), dp(10));

        TextView iconView = tv(icon, 24, Color.rgb(50, 50, 55));
        row.addView(iconView, new LinearLayout.LayoutParams(dp(55), dp(58)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);

        TextView titleView = tv(title, 17, Color.rgb(35, 35, 40));
        titleView.setTypeface(null, 1);
        titleView.setPadding(0, 0, 0, 0);
        texts.addView(titleView);

        if (!subtitle.isEmpty()) {
            TextView sub = tv(subtitle, 13, Color.GRAY);
            sub.setPadding(0, 0, 0, 0);
            texts.addView(sub);
        }

        row.addView(texts, new LinearLayout.LayoutParams(0, -2, 1));

        TextView arrow = tv("›", 30, Color.GRAY);
        arrow.setGravity(Gravity.CENTER);
        row.addView(arrow, new LinearLayout.LayoutParams(dp(35), dp(58)));

        row.setClickable(true);
        row.setBackgroundColor(Color.WHITE);
        row.setOnClickListener(listener);
        content.addView(row);
    }

    void showInfoPage(String title, String message) {
        base(Color.rgb(220, 20, 20), Color.WHITE);
        content.removeAllViews();
        TextView heading = tv(title, 26, Color.rgb(35, 35, 35));
        heading.setTypeface(null, 1);
        content.addView(heading);
        content.addView(tv(message, 16, Color.DKGRAY));
        Button back = new Button(this);
        back.setText("Back to Profile");
        back.setAllCaps(false);
        content.addView(back, new LinearLayout.LayoutParams(-1, dp(58)));
        back.setOnClickListener(v -> buildProfile());
    }

    void buildProfile() {
        // YouTube-inspired profile style: red header + white account list.
        base(Color.rgb(220, 20, 20), Color.WHITE);
        content.removeAllViews();

        TextView title = tv("Profile", 26, Color.rgb(35, 35, 35));
        title.setTypeface(null, 1);
        content.addView(title);

        LinearLayout account = new LinearLayout(this);
        account.setGravity(Gravity.CENTER_VERTICAL);
        account.setPadding(dp(20), dp(18), dp(16), dp(18));

        TextView avatar = tv("A", 34, Color.WHITE);
        avatar.setGravity(Gravity.CENTER);
        avatar.setBackgroundColor(Color.rgb(245, 30, 30));
        account.addView(avatar, new LinearLayout.LayoutParams(dp(70), dp(70)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(14), 0, 0, 0);

        TextView name = tv("AdPoint User", 20, Color.rgb(35, 35, 35));
        name.setTypeface(null, 1);
        name.setPadding(0, 0, 0, 0);
        info.addView(name);

        TextView accountText = tv("Manage your AdPoint account", 14, Color.GRAY);
        accountText.setPadding(0, dp(4), 0, 0);
        info.addView(accountText);

        account.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        content.addView(account);

        // Requested name: Your Channel -> Your Account.
        addProfileRow("👤", "Your Account", "View and manage your account", v -> showInfoPage("Your Account", "Account features will appear here."));
        addProfileRow("◷", "History", "Watch & ad history", v -> showInfoPage("History", "Your watch and ad history will appear here."));
        addProfileRow("☷", "Saved", "Your saved items", v -> showInfoPage("Saved", "Your saved items will appear here."));
        addProfileRow("◷", "Watch Later", "Items you save for later", v -> showInfoPage("Watch Later", "Items saved for later will appear here."));
        addProfileRow("?", "Help & Support", "", v -> showInfoPage("Help & Support", "For help, contact the app support team."));
        addProfileRow("▤", "Terms & Conditions", "", v -> showInfoPage("Terms & Conditions", "Please use the app responsibly and follow all applicable rules."));
        addProfileRow("⌑", "Privacy Policy", "", v -> showInfoPage("Privacy Policy", "Your privacy policy details will appear here."));
        addProfileRow("ⓘ", "About", "", v -> showInfoPage("About", "AdPoint v1.0
Watch rewarded test ads and earn demo points."));
    }

    void loadRewardedAd() {
        RewardedAd.load(this, AD_UNIT_ID, new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(RewardedAd ad) {
                        rewardedAd = ad;
                        lastAdError = "";
                        updateButtons();
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError e) {
                        rewardedAd = null;
                        lastAdError = e.getMessage() == null ? "Ad failed to load" : e.getMessage();
                        updateButtons();
                    }
                });
    }

    void watchAd() {
        if (adsToday >= DAILY_LIMIT) {
            toast("Today's 20-ad limit reached.");
            return;
        }

        if (rewardedAd == null) {
            toast("Ad is loading. Try again in a moment.");
            loadRewardedAd();
            return;
        }

        RewardedAd ad = rewardedAd;
        rewardedAd = null;

        if (watchButton != null) watchButton.setEnabled(false);

        ad.show(this, rewardItem -> {
            points += POINTS_PER_AD;
            adsToday++;

            sp.edit()
                    .putInt("points", points)
                    .putInt("ads", adsToday)
                    .putInt("earned", sp.getInt("earned", 0) + POINTS_PER_AD)
                    .apply();

            toast("+50 points added!");
            loadRewardedAd();
            updateButtons();
        });
    }

    void requestRedeem() {
        if (points < REDEEM_POINTS) {
            toast("You need " + (REDEEM_POINTS - points) + " more points.");
            return;
        }

        points -= REDEEM_POINTS;
        sp.edit()
                .putInt("points", points)
                .putInt("redeemed", sp.getInt("redeemed", 0) + REDEEM_POINTS)
                .apply();

        toast("Redeem request submitted (demo).");
        buildRedeem();
    }

    void updateButtons() {
        if (watchButton != null) {
            watchButton.setEnabled(adsToday < DAILY_LIMIT && rewardedAd != null);

            if (statusText != null) {
                if (rewardedAd == null) {
                    if (lastAdError.isEmpty()) statusText.setText("Loading rewarded ad…");
                    else statusText.setText("Ad load failed: " + lastAdError + " • Tap Watch to retry.");
                } else statusText.setText("Rewarded test ad ready • " + adsToday + "/" + DAILY_LIMIT + " today");
            }
        }

        if (pointsText != null) pointsText.setText(points + " points");
        if (adsText != null) adsText.setText("Today's Ads: " + adsToday + " / " + DAILY_LIMIT);
    }

    void save() {
        sp.edit().putString("day", day).apply();
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
