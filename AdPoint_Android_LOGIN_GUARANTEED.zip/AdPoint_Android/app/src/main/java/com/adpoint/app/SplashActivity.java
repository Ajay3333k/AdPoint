package com.adpoint.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;

public class SplashActivity extends Activity {
    int dp(float x) { return (int)(x * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(10, 16, 40));

        TextView logo = new TextView(this);
        logo.setText("AP");
        logo.setTextSize(34);
        logo.setTextColor(Color.WHITE);
        logo.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.rgb(109, 74, 255));
        logo.setBackground(bg);
        root.addView(logo, new LinearLayout.LayoutParams(dp(112), dp(112)));

        TextView name = new TextView(this);
        name.setText("AdPoint Gaming");
        name.setTextSize(30);
        name.setTextColor(Color.WHITE);
        name.setGravity(Gravity.CENTER);
        name.setPadding(0, dp(20), 0, 0);
        root.addView(name);

        TextView sub = new TextView(this);
        sub.setText("PLAY • EARN • TRACK • REDEEM");
        sub.setTextSize(15);
        sub.setTextColor(Color.LTGRAY);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);

        setContentView(root);

        new Handler().postDelayed(() -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }, 1200);
    }
}
