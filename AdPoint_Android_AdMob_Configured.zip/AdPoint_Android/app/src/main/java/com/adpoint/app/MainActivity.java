package com.adpoint.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final String AD_UNIT_ID = "ca-app-pub-6915600224604560/8485757967";
    private static final int DAILY_LIMIT = 20, POINTS_PER_AD = 50, REDEEM_POINTS = 2000;
    private SharedPreferences sp;
    private RewardedAd rewardedAd;
    private Button watchButton;
    private TextView pointsText, adsText, statusText;
    private LinearLayout content;
    private int points, adsToday;
    private String day;

    int dp(float x){ return (int)(x*getResources().getDisplayMetrics().density+.5f); }
    TextView tv(String text,int size,int color){ TextView t=new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(color); t.setPadding(dp(16),dp(10),dp(16),dp(10)); return t; }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        sp=getSharedPreferences("adpoint",MODE_PRIVATE);
        day=sp.getString("day","");
        String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
        if(!today.equals(day)){ adsToday=0; day=today; save(); }
        points=sp.getInt("points",0); adsToday=sp.getInt("ads",0);
        MobileAds.initialize(this, status -> {});
        buildHome();
        loadRewardedAd();
    }

    void base(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(246,248,255));
        LinearLayout header=new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL); header.setPadding(dp(20),dp(22),dp(20),dp(24)); header.setBackgroundColor(Color.rgb(13,43,120));
        TextView brand=tv("AdPoint",25,Color.WHITE); brand.setTypeface(null,1); header.addView(brand);
        header.addView(tv("Watch Ads. Earn Points. Redeem Rewards.",14,Color.WHITE));
        root.addView(header,new LinearLayout.LayoutParams(-1,dp(120)));
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); ScrollView scroll=new ScrollView(this); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setPadding(4,4,4,8); nav.setBackgroundColor(Color.WHITE);
        String[] labels={"Home","Watch","Wallet","Redeem","Profile"};
        for(String l:labels){ Button n=new Button(this); n.setText(l); n.setTextSize(11); n.setAllCaps(false); nav.addView(n,new LinearLayout.LayoutParams(0,dp(58),1)); n.setOnClickListener(v->{ if(l.equals("Home"))buildHome(); else if(l.equals("Watch"))buildWatch(); else if(l.equals("Wallet"))buildWallet(); else if(l.equals("Redeem"))buildRedeem(); else buildProfile();});}
        root.addView(nav,new LinearLayout.LayoutParams(-1,dp(64)));
        setContentView(root);
    }

    void buildHome(){ base(); content.removeAllViews();
        TextView title=tv("Your Points",14,Color.GRAY); content.addView(title);
        pointsText=tv(points+" points",36,Color.rgb(20,30,65)); pointsText.setTypeface(null,1); content.addView(pointsText);
        adsText=tv("Today's Ads: "+adsToday+" / "+DAILY_LIMIT,16,Color.DKGRAY); content.addView(adsText);
        TextView rule=tv("1 ad = 50 points  •  2,000 points = ₹10 redeem",14,Color.rgb(90,54,215)); content.addView(rule);
        watchButton=new Button(this); watchButton.setText("🎬  Watch Ad & Earn 50 Points"); watchButton.setAllCaps(false); watchButton.setTextColor(Color.WHITE); watchButton.setBackgroundResource(com.adpoint.app.R.drawable.button_bg); content.addView(watchButton,new LinearLayout.LayoutParams(-1,dp(60))); watchButton.setOnClickListener(v->watchAd());
        statusText=tv("",13,Color.GRAY); content.addView(statusText);
        TextView note=tv("Rewards are granted only after the ad SDK reports a genuine earned reward.",13,Color.DKGRAY); content.addView(note);
        updateButtons();
    }

    void buildWatch(){ buildHome(); }

    void buildWallet(){ base(); content.removeAllViews(); content.addView(tv("Wallet",24,Color.rgb(20,30,65))); content.addView(tv(points+" points available",28,Color.rgb(20,30,65))); content.addView(tv("Total earned: "+sp.getInt("earned",0)+" points",16,Color.DKGRAY)); content.addView(tv("Redeemed: "+sp.getInt("redeemed",0)+" points",16,Color.DKGRAY)); }

    void buildRedeem(){ base(); content.removeAllViews(); content.addView(tv("Redeem",24,Color.rgb(20,30,65))); content.addView(tv("🎁  Google Play Redeem Code",20,Color.rgb(20,30,65))); content.addView(tv("2,000 points = ₹10 redeem request",15,Color.DKGRAY)); Button r=new Button(this); r.setText("Redeem Now"); r.setAllCaps(false); content.addView(r,new LinearLayout.LayoutParams(-1,dp(60))); r.setOnClickListener(v->requestRedeem()); content.addView(tv("Balance: "+points+" points",15,Color.GRAY)); }

    void buildProfile(){ base(); content.removeAllViews(); content.addView(tv("Profile",24,Color.rgb(20,30,65))); content.addView(tv("👤  AdPoint User",20,Color.rgb(20,30,65))); content.addView(tv("Help & Support\nTerms & Conditions\nPrivacy Policy",16,Color.DKGRAY)); }

    void loadRewardedAd(){
        RewardedAd.load(this,AD_UNIT_ID,new AdRequest.Builder().build(),new RewardedAdLoadCallback(){
            @Override public void onAdLoaded(RewardedAd ad){ rewardedAd=ad; updateButtons(); }
            @Override public void onAdFailedToLoad(LoadAdError e){ rewardedAd=null; updateButtons(); }
        });
    }

    void watchAd(){
        if(adsToday>=DAILY_LIMIT){ toast("Today's 20-ad limit reached."); return; }
        if(rewardedAd==null){ toast("Ad is loading. Try again in a moment."); loadRewardedAd(); return; }
        RewardedAd ad=rewardedAd; rewardedAd=null; watchButton.setEnabled(false);
        ad.show(this, rewardItem -> {
            // IMPORTANT: points are awarded only from the official earned-reward callback.
            points += POINTS_PER_AD; adsToday++;
            sp.edit().putInt("points",points).putInt("ads",adsToday).putInt("earned",sp.getInt("earned",0)+POINTS_PER_AD).apply();
            toast("+50 points added!");
            loadRewardedAd(); updateButtons();
        });
    }

    void requestRedeem(){
        if(points<REDEEM_POINTS){ toast("You need "+(REDEEM_POINTS-points)+" more points."); return; }
        // Demo only: real redemption must be server-side.
        points-=REDEEM_POINTS; sp.edit().putInt("points",points).putInt("redeemed",sp.getInt("redeemed",0)+REDEEM_POINTS).apply();
        toast("Redeem request submitted (demo)."); buildRedeem();
    }

    void updateButtons(){
        if(watchButton!=null){ watchButton.setEnabled(adsToday<DAILY_LIMIT && rewardedAd!=null); if(rewardedAd==null) statusText.setText("Loading rewarded ad…"); else statusText.setText("Rewarded ad ready • "+adsToday+"/"+DAILY_LIMIT+" today"); }
        if(pointsText!=null) pointsText.setText(points+" points");
        if(adsText!=null) adsText.setText("Today's Ads: "+adsToday+" / "+DAILY_LIMIT);
    }
    void save(){ sp.edit().putString("day",day).apply(); }
    void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
}
